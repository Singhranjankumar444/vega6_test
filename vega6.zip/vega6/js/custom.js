function openNav() {
    document.getElementById("sidebar-menu").style.width = "320px";
}

function closeNav() {
    document.getElementById("sidebar-menu").style.width = "0";
}
$(document).ready(function () {
    $('.review-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 2000,
        dots: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 2
            }
        }
    });
});

